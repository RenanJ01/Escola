<?php
class Home
{
    public function getDadosHome()
    {
        $home["Usuario"] = "CTII 448";
        $home["Email"] = "trabalho@dsw.ifsp";
        $home["Senha"] = "123456";
        return $home;
    }
}
?>