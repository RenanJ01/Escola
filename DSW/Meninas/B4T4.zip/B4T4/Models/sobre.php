<?php
class Sobre
{
    public function getDadosSobre()
    {
        $sobre["Empresa"] = "Eriel and Renan: Express";
        $sobre['Subtitulo'] = "A Mercearia Online para sua Conveniência";
        return $sobre;
    }
}
?>