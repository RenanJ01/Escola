<div>
    <p>
        <b>Bem-Vindo</b> <br>
        Usuario:
        <?php echo $Usuario ?> <br>
        Email:
        <?php echo $Email ?> <br>
        Senha:
        <?php echo $Senha ?>
    </p>
    <br />
</div>