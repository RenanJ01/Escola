<div>
    <h1>
        <?php echo $Empresa ?>
    </h1>
    <h3>
        <?php echo $Subtitulo ?>
    </h3>
    <br>
</div>