<div>
    <h1>Produto</h1>
    <p> <?php echo '<b> Codígo: </b>'.$codigo.' <br> <b>Nome: </b>'.$nome.' <br><b> Marca: </b>'.$marca.'<br><b> Preço: </b>$'.$preco ?></p>
    <br>
    <a class="links" href="../../produto">Lista Produtos</a>
</div>