<?php
require 'autoload.php';
$c = new Core();
?>